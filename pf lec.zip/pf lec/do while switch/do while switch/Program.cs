﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace do_while_switch
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
