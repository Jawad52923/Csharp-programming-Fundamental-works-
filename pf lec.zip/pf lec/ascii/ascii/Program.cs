﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ascii
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int i = 65; i <= 90; i++)
            {

                Console.WriteLine("{0} = {1}", i, (char)i);

            }
        }
    }
}
