﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace nested_if
{
    class Program
    {
        static void Main(string[] args)
        {
            nested_if_statement nis = new nested_if_statement();
            nis.nested_if_method();
        }
    }
}
