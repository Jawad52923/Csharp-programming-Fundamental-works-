﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication26
{
    class Program
    {
        static void Main(string[] args)
        {

            string op = Console.ReadLine();
            switch (op)
            {
                case "+":
                    int[] sum = new int[3];
                    Console.WriteLine("enter first num:");
                    int a = Convert.ToInt16(Console.ReadLine());
                    Console.WriteLine("enter second num:");
                    int b = Convert.ToInt16(Console.ReadLine());
                    for (int i = 0; i < sum.Length; i++)
                    {
                        sum[i] = a + b;
                        Console.WriteLine(sum[i]);
                    }

                    Console.WriteLine("do you want to perform any other function? yes /no");
                    string ans = Console.ReadLine();
                    if (ans == "yes")
                    {
                        Console.WriteLine("select operator");
                        string op2 = Console.ReadLine();
                        if (op2 == "+")
                        {
                            int c = Convert.ToInt16(Console.ReadLine());
                            int sum2 = sum[0] + c;
                            Console.WriteLine(sum2);
                        }
                        else if (op2 == "-")
                        {
                            int[] sub = new int[3];
                            int c1 = Convert.ToInt16(Console.ReadLine());

                            for (int i = 0; i < sub.Length; i++)
                            {
                                sub[i] = a - b;
                                Console.WriteLine(sub[i]);
                            }
                            Console.WriteLine(sub);
                        }

                    }
                    break;

            }
        }
    }
}
